<?php
require_once __DIR__ . '/vendor/autoload.php';

use Web3\Web3;
use Web3\Contract;
use Web3\Providers\HttpProvider;
use Web3\RequestManagers\HttpRequestManager;

class BlockchainService
{
    private $web3;
    private $config;

    public function __construct()
    {
        $this->config = require __DIR__ . '/config/blockchain.php';
        $this->web3 = new Web3(
            new HttpProvider(
                new HttpRequestManager($this->config['rpc_url'], 10)
            )
        );
    }

    public function verificarConexion(): bool
    {
        $version = null;
        $this->web3->clientVersion(function ($err, $result) use (&$version) {
            if ($err !== null) {
                throw new Exception("Error de conexion: " . $err->getMessage());
            }
            $version = $result;
        });
        return $version !== null;
    }

    public function obtenerVersionCliente(): string
    {
        $version = '';
        $this->web3->clientVersion(function ($err, $result) use (&$version) {
            if ($err === null) {
                $version = $result;
            }
        });
        return $version;
    }

    public function obtenerBalance(): string
    {
        return $this->llamarFuncionSinParametrosUint('obtenerBalanceContrato');
    }

    public function totalCampanas(): string
    {
        return $this->llamarFuncionSinParametrosUint('totalCampanas');
    }

    public function totalDonaciones(): string
    {
        return $this->llamarFuncionSinParametrosUint('totalDonaciones');
    }

    public function obtenerNombreCampana(int $idCampana): string
    {
        return $this->llamarFuncionString('obtenerNombreCampana', $idCampana);
    }

    public function obtenerDescripcionCampana(int $idCampana): string
    {
        return $this->llamarFuncionString('obtenerDescripcionCampana', $idCampana);
    }

    public function obtenerMetaFondos(int $idCampana): string
    {
        return $this->llamarFuncionUint('obtenerMetaFondos', $idCampana);
    }

    public function obtenerFondosRecaudados(int $idCampana): string
    {
        return $this->llamarFuncionUint('obtenerFondosRecaudados', $idCampana);
    }

    public function campanaEstaActiva(int $idCampana): bool
    {
        return $this->llamarFuncionBool('campanaEstaActiva', $idCampana);
    }

    public function obtenerDonaciones(int $idCampana): array
    {
        return $this->llamarFuncionArray('obtenerDonacionesPorCampana', $idCampana);
    }

    public function weiAEther(string $wei): string
    {
        return number_format((float) $wei / 1e18, 6, '.', '');
    }

    private function llamarFuncionSinParametrosUint(string $funcion): string
    {
        $abi = $this->cargarAbi();
        $contract = new Contract($this->web3->provider, $abi['abi']);
        $contract->at($this->config['contracts']['dona_chain']);

        $resultado = null;
        $contract->call($funcion, function ($err, $result) use (&$resultado) {
            if ($err !== null) {
                throw new Exception("Error al consultar {$funcion}: " . $err->getMessage());
            }
            $resultado = $result;
        });

        return isset($resultado[0]) ? (string) $resultado[0] : '0';
    }

    private function llamarFuncionString(string $funcion, int $idCampana): string
    {
        $abi = $this->cargarAbi();
        $contract = new Contract($this->web3->provider, $abi['abi']);
        $contract->at($this->config['contracts']['dona_chain']);

        $resultado = null;
        $contract->call($funcion, $idCampana, function ($err, $result) use (&$resultado) {
            if ($err !== null) {
                throw new Exception("Error al consultar {$funcion}: " . $err->getMessage());
            }
            $resultado = $result;
        });

        return $resultado[0] ?? '';
    }

    private function llamarFuncionUint(string $funcion, int $idCampana): string
    {
        $abi = $this->cargarAbi();
        $contract = new Contract($this->web3->provider, $abi['abi']);
        $contract->at($this->config['contracts']['dona_chain']);

        $resultado = null;
        $contract->call($funcion, $idCampana, function ($err, $result) use (&$resultado) {
            if ($err !== null) {
                throw new Exception("Error al consultar {$funcion}: " . $err->getMessage());
            }
            $resultado = $result;
        });

        return isset($resultado[0]) ? (string) $resultado[0] : '0';
    }

    private function llamarFuncionBool(string $funcion, int $idCampana): bool
    {
        $abi = $this->cargarAbi();
        $contract = new Contract($this->web3->provider, $abi['abi']);
        $contract->at($this->config['contracts']['dona_chain']);

        $resultado = null;
        $contract->call($funcion, $idCampana, function ($err, $result) use (&$resultado) {
            if ($err !== null) {
                throw new Exception("Error al consultar {$funcion}: " . $err->getMessage());
            }
            $resultado = $result;
        });

        return $resultado[0] ?? false;
    }

    private function llamarFuncionArray(string $funcion, int $idCampana): array
    {
        $abi = $this->cargarAbi();
        $contract = new Contract($this->web3->provider, $abi['abi']);
        $contract->at($this->config['contracts']['dona_chain']);

        $resultado = null;
        $contract->call($funcion, $idCampana, function ($err, $result) use (&$resultado) {
            if ($err !== null) {
                throw new Exception("Error al consultar {$funcion}: " . $err->getMessage());
            }
            $resultado = $result;
        });

        return $resultado ?? [];
    }

    private function cargarAbi(): array
    {
        return json_decode(
            file_get_contents($this->config['abi_path'] . 'DONAChain.json'),
            true
        );
    }
}