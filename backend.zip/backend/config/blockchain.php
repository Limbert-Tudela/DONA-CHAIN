<?php

return [
    'rpc_url' => 'http://127.0.0.1:8545',
    'chain_id' => 31337,
    'contracts' => [
        'dona_chain' => '0x5FbDB2315678afecb367f032d93F642f64180aa3',
        'quadratic_funding' => '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512'
    ],
    'abi_path' => __DIR__ . '/../abi/'
];