<?php
require_once __DIR__ . '/BlockchainService.php';

echo "========================================\n";
echo "  PRUEBA DE CONEXION PHP -> BLOCKCHAIN\n";
echo "========================================\n\n";

try {
    $service = new BlockchainService();

    echo "[1/5] Verificando conexion...\n";
    if ($service->verificarConexion()) {
        echo "      Conexion exitosa a la red blockchain\n";
        echo "      Cliente: " . $service->obtenerVersionCliente() . "\n\n";
    }

    echo "[2/5] Consultando balance del contrato...\n";
    $balanceWei = $service->obtenerBalance();
    $balanceEther = $service->weiAEther($balanceWei);
    echo "      Balance: {$balanceEther} ETH\n\n";

    echo "[3/5] Consultando totales...\n";
    $totalCampanas = $service->totalCampanas();
    $totalDonaciones = $service->totalDonaciones();
    echo "      Total campanas: {$totalCampanas}\n";
    echo "      Total donaciones: {$totalDonaciones}\n\n";

    echo "[4/5] Consultando campana #1...\n";
    $nombre = $service->obtenerNombreCampana(1);
    $descripcion = $service->obtenerDescripcionCampana(1);
    $meta = $service->obtenerMetaFondos(1);
    $fondos = $service->obtenerFondosRecaudados(1);
    $activa = $service->campanaEstaActiva(1);

    echo "      Nombre: {$nombre}\n";
    echo "      Descripcion: {$descripcion}\n";
    echo "      Meta: " . $service->weiAEther($meta) . " ETH\n";
    echo "      Fondos recaudados: " . $service->weiAEther($fondos) . " ETH\n";
    echo "      Activa: " . ($activa ? 'Si' : 'No') . "\n\n";

    echo "[5/5] Consultando donaciones de la campana #1...\n";
    $donaciones = $service->obtenerDonaciones(1);
    echo "      Total donaciones registradas: " . count($donaciones) . "\n\n";

    echo "========================================\n";
    echo "  PRUEBA COMPLETADA EXITOSAMENTE\n";
    echo "========================================\n";

} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}